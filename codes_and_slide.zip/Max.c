


int max( int a, int b ) {
    if( a > b ) {
        return a;
    } else {
        return b;
    }
}

int max2( int a, int b ) {
    return (a > b) * a + (a <= b) * b;
}

int max3( int a, int b ) {
    return (a > b) ? a : b;
}


static inline int max4( int a, int b ) {
    return (a > b) ? a : b;
}

#define max5( a, b ) ((a > b) ? a : b)

int main() {
    unsigned long int N = 1000000000;

    for( int long i = 0; i < N; i++ ) {
        max3( i, i + 1);
    }
    return 0;
}