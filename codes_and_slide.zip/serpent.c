#include <stdio.h>
#define uint32 unsigned int
#define uint8  unsigned int

/*
uint32 rotl( uint32 v, uint8 n ) {
    uint32 r = v;
    for( int i = 0; i < n; i++ ) {
        r = (r << 1) | (r >> 31);
    }
    return r;
}


uint32 rotl( uint32 v, uint8 n ) {
    return (v << n) | (v >> (32 - n));
}

static inline uint32 rotl( uint32 v, uint8 n ) {
    return (v << n) | (v >> (32 - n));
}
*/
#define rotl(v, n) ((v << n) | (v >> (32 - n)))

int main() {
    uint32 N = 1000000000;   
    uint32 X0 = 0x78873269, X1 = 0x44844211, X2 = 0x1D87FDCC, X3 = 0xAF873205;
    for( int i = 0; i < N; i++ ) {
        X0 = rotl(X0, 13);
        X2 = rotl(X2, 3);
        X1 = X1 ^ X0 ^ X2;
        X3 = X3 ^ X2 ^ rotl(X0, 3);
        X1 = rotl(X1, 1);
        X3 = rotl(X3, 7);
        X0 = X0 ^ X1 ^ X3;
        X2 = X2 ^ X3 ^ rotl(X1, 7);
        X0 = rotl(X0, 5);
        X2 = rotl(X2, 22);
    }
    printf("X3 = %X\n", X3);        
    return 0;
}
